<?php
$host = 'localhost'; // Ganti dengan host database Anda
$username = 'root'; // Ganti dengan username database Anda
$password = ''; // Ganti dengan password database Anda
$database = 'park'; // Ganti dengan nama database Anda

$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $vehiclePlate = $_POST["vehicle_plate"];
    $vehicleType = $_POST["vehicle_type"];
    $vehicleBrand = $_POST["vehicle_brand"];
    $entryTime = $_POST["entry_time"];
    $status = $_POST["status"];

    // Lakukan validasi data jika diperlukan

    $insertQuery = "INSERT INTO parkingrecords (vehicle_plate, vehicle_type, vehicle_brand, entry_time, status) VALUES ('$vehiclePlate', '$vehicleType', '$vehicleBrand', NOW(), 'Parked')";

    if (mysqli_query($conn, $insertQuery)) {
        header("Location: parking_data.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>
