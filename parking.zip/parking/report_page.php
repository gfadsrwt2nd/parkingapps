<!DOCTYPE html>
<html>
<head>
    <title>Halaman Laporan</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<style type="text/css">
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

.container {
    width: 80%;
    margin: auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 5px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

h2 {
    text-align: center;
    margin-bottom: 20px;
}

form {
    display: flex;
    flex-direction: column;
}

label {
    font-weight: bold;
    margin-bottom: 5px;
}

select, input[type="submit"] {
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 3px;
    font-size: 16px;
}

input[type="submit"] {
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 3px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s;
}

input[type="submit"]:hover {
    background-color: #0056b3;
}

.sidebar {
    width: 250px;
    background-color: #7a7a7a;
    color: #fff;
    height: 100%;
    position: fixed;
    transition: 0.3s;
    overflow-y: auto;
}

.sidebar.active {
    width: 60px;
}

.logo {
    padding: 10px;
    text-align: center;
    font-size: 1.5rem;
    font-weight: bold;
}

.menu {
    list-style: none;
    padding: 0;
    margin: 0;
}

.menu li {
    padding: 15px;
    text-align: left;
}

.menu a {
    text-decoration: none;
    color: #fff;
    transition: 0.3s;
    display: block;
}

.menu a:hover {
    background-color: #355e5d;
}

.content {
    margin-left: 250px;
    padding: 20px;
    transition: 0.3s;
}

.content.active {
    margin-left: 60px;
}
</style>
<body>
    <div class="sidebar">
        <div class="logo">
            <img src="img/logo.png" height="100">
        </div>
        <ul class="menu">
            <li><a href="dashboard.php">Beranda</a></li>
            <li><a href="parking_data.php">Data Parkir</a></li>
            <li><a href="settings_form.php">Tarif Parkir</a></li>
            <li><a href="transaction_history.php">Riwayat Transaksi</a></li>
            <li><a href="report_page.php">Laporan</a></li>
            <!-- Tambahkan menu lain sesuai kebutuhan -->
        </ul>
    </div>

    <div class="container">
        <h2>Halaman Laporan</h2>
        <form action="generate_report.php" method="POST">
            <label for="report_type">Pilih Jenis Laporan:</label>
            <select name="report_type" required>
                <option value="pilih">--Pilih--</option>
                <option value="parking_data">Data Parkir</option>
                <option value="revenue">Pendapatan</option>
                <!-- Tambahkan opsi lain sesuai kebutuhan -->
            </select>
            
            <input type="submit" value="Generate Laporan">
        </form>
    </div>
</body>
</html>
