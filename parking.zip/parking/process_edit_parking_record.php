<?php
// Memeriksa apakah form telah disubmit
if (isset($_POST["submit"])) {
    // Mengambil data dari form
    $record_id = $_POST["record_id"];
    $vehicle_plate = $_POST["vehicle_plate"];
    $vehicle_type = $_POST["vehicle_type"];
    $vehicle_brand = $_POST["vehicle_brand"];
    $status = $_POST["status"];
    $entry_time = $_POST["entry_time"];
    $exit_time = $_POST["exit_time"];

    // Menghubungkan ke database
    $conn = mysqli_connect("localhost", "root", "", "park");

    if ($exit_time !== null) {
        $query = "UPDATE parkingrecords SET vehicle_plate = '$vehicle_plate', vehicle_type = '$vehicle_type', vehicle_brand = '$vehicle_brand', entry_time = '$entry_time', exit_time = '$exit_time', status = '$status' WHERE record_id = $record_id";
    } else {
        $query = "UPDATE parkingrecords SET vehicle_plate = '$vehicle_plate', vehicle_type = '$vehicle_type', vehicle_brand = '$vehicle_brand', entry_time = '$entry_time', status = '$status' WHERE record_id = $record_id";
    }

    // Mengeksekusi query untuk mengupdate data parkir
    $query = "UPDATE parkingrecords SET vehicle_plate = '$vehicle_plate', vehicle_type = '$vehicle_type', vehicle_brand = '$vehicle_brand', entry_time = '$entry_time', exit_time = '$exit_time', status = '$status' WHERE record_id = $record_id";
    $result = mysqli_query($conn, $query);

    if ($result) {
        mysqli_close($conn);
        header("Location: parking_data.php"); // Redirect kembali ke halaman data parkir
        exit;
    } else {
        echo "Error: " . mysqli_error($conn);
    }

    mysqli_close($conn);
} else {
    echo "Form tidak disubmit.";
}
?>
