<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reportType = $_POST['report_type'];

    if ($reportType === 'parking_data') {
        // Redirect ke data_parkir_report.php jika jenis laporan adalah Data Parkir
        header('Location: data_parkir_report.php');
        exit;
    } elseif ($reportType === 'revenue') {
        // Redirect ke pendapatan_report.php jika jenis laporan adalah Pendapatan
        header('Location: pendapatan_report.php');
        exit;
    }
}
?>
