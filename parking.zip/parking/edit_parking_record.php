<!DOCTYPE html>
<html>
<head>
    <title>Edit Data Parkir</title>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
    <link rel="stylesheet" type="text/css" href="css/dashboard-styles.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<style>
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

.container {
    width: 80%;
    margin: auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 5px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

h2 {
    text-align: center;
    margin-bottom: 20px;
}

label {
    font-weight: bold;
}

input[type="text"],
select {
    width: 100%;
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 3px;
}

input[type="submit"] {
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 3px;
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s;
}

input[type="submit"]:hover {
    background-color: #0056b3;
}
</style>
<body>
    <div class="sidebar">
        <div class="logo">
            <img src="img/logo.png" height="100">
        </div>
        <ul class="menu">
            <li><a href="dashboard.php">Beranda</a></li>
            <li><a href="parking_data.php">Data Parkir</a></li>
            <li><a href="settings_form.php">Tarif Parkir</a></li>
            <li><a href="transaction_history.php">Riwayat Transaksi</a></li>
            <li><a href="report_page.php">Laporan</a></li>
            <!-- Tambahkan menu lain sesuai kebutuhan -->
        </ul>
    </div>

    <div class="container">
        <h2>Edit Data Parkir</h2>
        
        <?php
        $conn = mysqli_connect("localhost", "root", "", "park");

        if (!$conn) {
            die("Koneksi ke database gagal: " . mysqli_connect_error());
        }

        if (isset($_GET["id"])) {
            $record_id = $_GET["id"];

            $query = "SELECT * FROM parkingrecords WHERE record_id = $record_id";
            $result = mysqli_query($conn, $query);

            if ($result !== false && mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
        ?>

        <form action="process_edit_parking_record.php" method="post">
            <input type="hidden" name="record_id" value="<?php echo $row["record_id"]; ?>">
            <label for="vehicle_plate">Nomor Plat:</label>
            <input type="text" name="vehicle_plate" value="<?php echo $row["vehicle_plate"]; ?>">
            <label for="vehicle_type">Jenis Kendaraan:</label>
            <select name="vehicle_type">
                <option value="mobil" <?php if ($row["vehicle_type"] == "mobil") echo "selected"; ?>>Mobil</option>
                <option value="motor" <?php if ($row["vehicle_type"] == "motor") echo "selected"; ?>>Motor</option>
            </select>
            <label for="vehicle_brand">Merk Kendaraan:</label>
            <input type="text" name="vehicle_brand" value="<?php echo $row["vehicle_brand"]; ?>">
            <label for="entry_time">Waktu Masuk:</label>
            <input type="text" name="entry_time" value="<?php echo $row["entry_time"]; ?>">
            <label for="exit_time">Waktu Keluar:</label><br>
            <input type="datetime-local" name="exit_time" value="<?php echo $row["exit_time"]; ?>">
            <br><br>
            <label for="status">Status:</label>
            <select name="status">
                <option value="Waiting" <?php if ($row["status"] == "Waiting") echo "selected"; ?>>Waiting</option>
                <option value="Parked" <?php if ($row["status"] == "Parked") echo "selected"; ?>>Parked</option>
                <option value="Exit" <?php if ($row["status"] == "Exit") echo "selected"; ?>>Exit</option>
            </select>
            <input type="submit" name="submit" value="Simpan Perubahan">
        </form>

        <?php
            } else {
                echo "Data tidak ditemukan.";
            }
        } else {
            echo "ID data tidak ditemukan.";
        }

        mysqli_close($conn);
        ?>
    </div>
</body>
</html>
