<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "park";

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$sql = "SELECT * FROM parkingrates";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
  <title>Pengaturan Biaya Parkir</title>
</head>
<style type="text/css">
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

.container {
  max-width: 600px;
  margin: 0 12%;
  margin-top: 0 10%;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 5px;
  background-color: #f7f7f7;
}

label {
  display: block;
  margin-top: 10px;
}

input[type="text"] {
  width: 100%;
  padding: 8px;
  margin-top: 5px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

button[type="submit"] {
  background-color: #007bff;
  color: white;
  padding: 10px 15px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

button[type="submit"]:hover {
  background-color: #0056b3; /* Warna latar belakang saat hover */
}

.success-message {
  color: green;
  font-weight: bold;
  margin-top: 10px;
}

.sidebar {
    width: 250px;
    background-color: #7d7c7c;
    color: #fff;
    height: 100%;
    position: fixed;
    transition: 0.3s;
    overflow-y: auto;
}

.sidebar.active {
    width: 60px;
}

.logo {
    padding: 10px;
    text-align: center;
    font-size: 1.5rem;
    font-weight: bold;
}

.menu {
    list-style: none;
    padding: 0;
    margin: 0;
}

.menu li {
    padding: 15px;
    text-align: left;
}

.menu a {
    text-decoration: none;
    color: #fff;
    transition: 0.3s;
    display: block;
}

.menu a:hover {
    background-color: #919090;
}

/* Style untuk label */
label {
  display: block;
  margin-bottom: 5px;
  font-weight: bold;
}

/* Style untuk select */
select {
  width: 103%;
  padding: 8px;
  margin-top: 5px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

input {
  width: 100%;
  padding: 8px;
  margin-top: 5px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

.container2 {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 5px;
  background-color: #f9f9f9;
}

.delete-button {
  background-color: #dc3545;
  color: white;
  padding: 5px 10px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s;
}

.delete-button:hover {
  background-color: #c82333;
}

a {
  text-decoration: none;
}

.next-button {
  background-color: #199e38;
  color: white;
  padding: 9px 10px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s;
}

.next-button:hover {
  background-color: #146928;
}
</style>
<body>
  <div class="sidebar">
      <div class="logo">
          <img src="img/logo.png" height="100">
      </div>
        <ul class="menu">
          <li><a href="dashboard.php">Beranda</a></li>
          <li><a href="parking_data.php">Data Parkir</a></li>
          <li><a href="settings_form.php">Tarif Parkir</a></li>
          <li><a href="transaction_history.php">Riwayat Transaksi</a></li>
          <li><a href="report_page.php">Laporan</a></li>
          <!-- Tambahkan menu lain sesuai kebutuhan -->
        </ul>
  </div>
  <br><br>
  <div class="container">
    <h2>Pengaturan Biaya Parkir</h2>
    <form action="process_form.php" method="post">
            <label class="form-input" for="vehicle_type">Tipe Kendaraan:</label>
            <select class="form-input" name="vehicle_type" id="vehicle_type">
                <option value="mobil">Mobil</option>
                <option value="motor">Motor</option>
            </select>
            <label for="duration">Durasi :</label>
            <input type="text" name="duration" id="duration" placeholder="Contoh: 1 jam">
            <label class="form-input" for="fee1">Biaya Perjam:</label>
            <input type="number" name="fee1" id="fee1" placeholder="Contoh: 3000" step="3000" min="0">
            <label for="daily_rate">Biaya Harian:</label>
            <input type="text" name="daily_rate" id="daily_rate" placeholder="Contoh: Rp 50,000">

            <br><br>
            
            <!-- Tambahkan input untuk durasi dan biaya lainnya -->
            
            <button type="submit" name="submit">Simpan Pengaturan</button>
            <a class="next-button" href="settings_page.php">Lihat Semua Tarif</a>
        </form>
  </div>
  <br>
  

</body>
</html>

<?php
$conn->close();
?>