<?php
if (isset($_POST["submit"])) {
    // Ambil data dari formulir
    $vehicle_type = $_POST["vehicle_type"];
    $duration = $_POST["duration"]; // Menggunakan nama yang benar, yaitu "duration"
    $fee1 = $_POST["fee1"];
    $daily_rate = $_POST["daily_rate"];

    // Periksa jika ada kolom yang wajib diisi yang kosong
    if (empty($duration) || empty($fee1) || empty($daily_rate)) {
        echo "Error: Semua kolom harus diisi.";
    } else {
        // Hubungkan ke database
        $host = "localhost";
        $username = "root";
        $password = "";
        $dbname = "park";

        $conn = new mysqli($host, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Koneksi gagal: " . $conn->connect_error);
        }

        // Jalankan kueri untuk menyimpan data
        $sql = "INSERT INTO parkingrates (vehicle_type, duration, hourly_rate, daily_rate)
        VALUES ('$vehicle_type', '$duration', '$fee1', '$daily_rate')";

        
        if ($conn->query($sql) === TRUE) {
            mysqli_close($conn);
            header("Location: settings_page.php");
            exit;
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

        $conn->close();
    }
} else {
    echo "Formulir tidak dikirim.";
}
?>
