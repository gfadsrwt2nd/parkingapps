<?php
// Mengecek apakah ID rekaman telah dikirim melalui parameter URL
if (isset($_GET["id"])) {
    $record_id = $_GET["id"];

    // Menghubungkan ke database
    $conn = mysqli_connect("localhost", "root", "", "park");

    if (!$conn) {
        die("Koneksi ke database gagal: " . mysqli_connect_error());
    }

    // Mengeksekusi query untuk menghapus data parkir
    $query = "DELETE FROM parkingrecords WHERE record_id = $record_id";
    $result = mysqli_query($conn, $query);

    if ($result) {
        mysqli_close($conn);
        header("Location: parking_data.php"); // Redirect kembali ke halaman data parkir
        exit;
    } else {
        echo "Error: " . mysqli_error($conn);
    }

    mysqli_close($conn);
} else {
    echo "ID rekaman tidak ditemukan.";
}
?>
