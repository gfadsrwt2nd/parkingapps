<!DOCTYPE html>
<html>
<head>
    <title>Hasil Pencarian Data Parkir</title>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
    <link rel="stylesheet" type="text/css" href="css/dashboard-styles.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Tambahkan link ke file CSS Anda di sini -->
</head>
<style type="text/css">
/* Style untuk elemen <table> */
table {
    width: 100%;
    border-collapse: collapse;
    border: 1px solid #ccc;
}

/* Style untuk elemen <tr> */
tr {
    background-color: #f2f2f2; /* Warna latar belakang baris genap */
}

/* Style untuk elemen <th> */
th, td {
    padding: 8px;
    border: 1px solid #ccc;
    text-align: center;
}

/* Style untuk elemen <th> pada baris header */
th {
    background-color: #007bff;
    color: #fff;
}

/* Style untuk elemen <td> pada baris yang di-hover */
tr:hover td {
    background-color: #e0e0e0;
}

</style>
<body>
    <div class="sidebar">
        <div class="logo">
            <img src="img/logo.png" height="100">
        </div>
        <ul class="menu">
            <li><a href="dashboard.php">Beranda</a></li>
            <li><a href="parking_data.php">Data Parkir</a></li>
            <li><a href="settings_form.php">Tarif Parkir</a></li>
            <li><a href="transaction_history.php">Riwayat Transaksi</a></li>
            <li><a href="report_page.php">Laporan</a></li>
            <!-- Tambahkan menu lain sesuai kebutuhan -->
        </ul>
    </div>

    <div class="container">
        <h2>Hasil Pencarian Data Parkir</h2>
        
        <?php
        if (isset($_GET['search'])) {
            $search = $_GET['search'];

            // Lakukan kueri SQL untuk mencari data sesuai pencarian
            $conn = mysqli_connect("localhost", "root", "", "park");
            $query = "SELECT * FROM parkingrecords WHERE vehicle_plate LIKE '%$search%'";
            $result = mysqli_query($conn, $query);

            if ($result && mysqli_num_rows($result) > 0) {
                echo "<table>"; // Mulai tabel
                echo "<tr><th>No.</th><th>Nomor Plat</th><th>Jenis Kendaraan</th><th>Merk</th><th>Waktu Masuk</th><th>Waktu Keluar</th><th>Status</th></tr>";

                $counter = 1;
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . $counter . "</td>";
                    echo "<td>" . $row["vehicle_plate"] . "</td>";
                    echo "<td>" . $row["vehicle_type"] . "</td>";
                    echo "<td>" . $row["vehicle_brand"] . "</td>";
                    echo "<td>" . $row["entry_time"] . "</td>";
                    echo "<td>" . $row["exit_time"] . "</td>";
                    echo "<td>" . $row["status"] . "</td>";
                    echo "</tr>";
                    $counter++;
                }

                echo "</table>"; // Akhiri tabel
            } else {
                echo "<p>Data tidak ditemukan.</p>";
            }

            mysqli_close($conn);
        }
        ?>
        
        <br>
        <a class="back-button" href="javascript:history.go(-1)">Kembali</a>
    </div>
    <!-- Tambahkan link ke file JavaScript Anda di sini -->
</body>
</html>
