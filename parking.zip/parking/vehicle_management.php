<!DOCTYPE html>
<html>
<head>
    <title>Manajemen Kendaraan</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<style type="text/css">
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

.sidebar {
    width: 250px;
    background-color: #7a7a7a;
    color: #fff;
    height: 100%;
    position: fixed;
    transition: 0.3s;
    overflow-y: auto;
}

.sidebar.active {
    width: 60px;
}

.logo {
    padding: 20px;
    text-align: center;
    font-size: 1.5rem;
    font-weight: bold;
}

.menu {
    list-style: none;
    padding: 0;
    margin: 0;
}

.menu li {
    padding: 15px;
    text-align: left;
}

.menu a {
    text-decoration: none;
    color: #fff;
    transition: 0.3s;
    display: block;
}

.menu a:hover {
    background-color: #696565;
}

.content {
    margin-left: 250px;
    padding: 20px;
    transition: 0.3s;
}

.dey {
    margin-right: 80%;
}

.deyh2 {
    margin-left: 200%;
}

.content.active {
    margin-left: 60px;
}

.container {
    width: 80%;
    margin: auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 5px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

h2, h3 {
    text-align: center;
    margin: 20px 0;
}

form {
    display: flex;
    flex-direction: column;
    max-width: 300px;
    margin: auto;
}

label {
    font-weight: bold;
    margin-bottom: 5px;
}

select, input[type="text"], input[type="submit"] {
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 3px;
    font-size: 16px;
}

input[type="submit"] {
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 3px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s;
}

input[type="submit"]:hover {
    background-color: #0056b3;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th, td {
    border: 1px solid #ccc;
    padding: 8px;
    text-align: center;
}

thead {
    background-color: #007bff;
    color: #fff;
}

tbody tr:nth-child(even) {
    background-color: #f2f2f2;
}

tbody tr:hover {
    background-color: #e0e0e0;
}

.logo {
    padding: 10px;
    text-align: center;
    font-size: 1.5rem;
    font-weight: bold;
}

.table-container {
    text-align: center;
    margin: auto;
}
</style>
<body>
    <?php
    $host = 'localhost'; // Nama Host
    $username = 'root'; // Username Database
    $password = ''; // Password Database
    $database = 'park'; // Nama Database

    $conn = mysqli_connect($host, $username, $password, $database);

    if (!$conn) {
        die("Koneksi ke database gagal: " . mysqli_connect_error());
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $vehicleType = $_POST["vehicle_type"];
        $vehiclePlate = $_POST["vehicle_plate"];
        $vehicleBrand = $_POST["vehicle_brand"]; // Menambahkan data merk kendaraan

        // Lakukan validasi data jika diperlukan

        $insertQuery = "INSERT INTO vehicle (vehicle_type, vehicle_plate, vehicle_brand) 
                        VALUES ('$vehicleType', '$vehiclePlate', '$vehicleBrand')";

        if (mysqli_query($conn, $insertQuery)) {
            echo "Data kendaraan berhasil ditambahkan.";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }


    ?>
    <div class="sidebar">
        <div class="logo">
            <img src="img/logo.png" height="100">
        </div>
        <ul class="menu">
            <li><a href="dashboard.php">Beranda</a></li>
            <li><a href="parking_data.php">Data Parkir</a></li>
            <li><a href="transaction_history.php">Riwayat Transaksi</a></li>
            <li><a href="vehicle_management.php">Manajemen Kendaraan</a></li>
            <li><a href="report_page.php">Laporan</a></li>
            <!-- Tambahkan menu lain sesuai kebutuhan -->
        </ul>
    </div>

    <div class="content">
        <div class="dey">
            <h2>Manajemen Kendaraan</h2>
            <form action="process_vehicle_management.php" method="post">
                <label for="vehicle_type">Jenis Kendaraan:</label>
                <select name="vehicle_type">
                    <option value="Mobil">Mobil</option>
                    <option value="Motor">Motor</option>
                </select>
                <label for="vehicle_brand">Merk Kendaraan:</label>
                <input type="text" name="vehicle_brand"> <!-- Menambahkan input untuk merk kendaraan -->
                <label for="vehicle_plate">Nomor Plat:</label>
                <input type="text" name="vehicle_plate">
                <input type="submit" name="submit" value="Tambah Kendaraan">
            </form>
        </div>
        <!-- Tambahkan tabel atau konten lain untuk menampilkan daftar kendaraan yang dikelola -->
    </div>



    <div class="content section">
        <h3>Daftar Kendaraan</h3>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Jenis Kendaraan</th>
                        <th>Nomor Plat</th>
                        <th>Merk</th>
                        <th>Waktu Masuk</th>
                        <!-- Tambahkan kolom lain sesuai kebutuhan -->
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $query = "SELECT * FROM vehicle";
                    $result = mysqli_query($conn, $query);

                    if (!$result) {
                        echo "Error: " . mysqli_error($conn);
                    } else {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>";
                            echo "<td>" . $row["vehicle_id"] . "</td>";
                            echo "<td>" . $row["vehicle_type"] . "</td>";
                            echo "<td>" . $row["vehicle_plate"] . "</td>";
                            echo "<td>" . $row["vehicle_brand"] . "</td>";
                            echo "<td>" . $row["entry_time"] . "</td>";
                            // Tambahkan kolom lain sesuai kebutuhan
                            echo "</tr>";
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
