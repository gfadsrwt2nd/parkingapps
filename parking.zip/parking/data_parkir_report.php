<?php
// Mulai sesi PHP
session_start();

// Periksa apakah pengguna sudah login (sesuaikan dengan cara Anda menangani autentikasi)
if (!isset($_SESSION['user_id'])) {
    // Jika pengguna tidak ada dalam sesi, alihkan ke halaman login atau lakukan tindakan lain yang sesuai.
    // header("Location: login.php");
    // exit();
}

// Menghubungkan ke database
$conn = mysqli_connect("localhost", "root", "", "park");

if (!$conn) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}

// Mengambil data dari tabel parkingrecords
$query = "SELECT * FROM parkingrecords";
$result = mysqli_query($conn, $query);

if (!$result) {
    die("Error dalam menjalankan query: " . mysqli_error($conn));
}

// Buat laporan dalam format HTML
$htmlDataParkir = "<html>
<head>
    <title>Laporan Data Parkir</title>
</head>
<style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }
        h1 {
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        .footer {
            text-align: center;
            margin-top: 20px;
        }
    </style>
<body>
    <h1>Laporan Data Parkir</h1>
    <table>
        <tr>
            <th>No.</th>
            <th>Record ID</th>
            <th>Nomor Plat</th>
            <th>Waktu Masuk</th>
            <th>Waktu Keluar</th>
            <th>Durasi Parkir</th>
            <th>Biaya</th>
        </tr>";

$counter = 1;
while ($row = mysqli_fetch_assoc($result)) {
    // Hitung durasi parkir (misalnya dalam menit)
    $entryTime = strtotime($row["entry_time"]);
    $exitTime = strtotime($row["exit_time"]);
    $parkingDuration = round(($exitTime - $entryTime) / 60);


    // Hitung biaya parkir
    $tarifPerJam = 5000; // Rp 5.000 per jam
    $biayaParkir = $parkingDuration * ($tarifPerJam / 60); // Ubah tarif per jam menjadi per menit

    // Tambahkan baris data ke laporan
    $htmlDataParkir .= "<tr>";
    $htmlDataParkir .= "<td>" . $counter . "</td>";
    $htmlDataParkir .= "<td>" . $row["record_id"] . "</td>";
    $htmlDataParkir .= "<td>" . $row["vehicle_plate"] . "</td>";
    $htmlDataParkir .= "<td>" . $row["entry_time"] . "</td>";
    $htmlDataParkir .= "<td>" . $row["exit_time"] . "</td>";
    $htmlDataParkir .= "<td>" . $parkingDuration . " menit</td>";
    $htmlDataParkir .= "<td>Rp " . number_format($biayaParkir, 2) . "</td>";
    $htmlDataParkir .= "</tr>";
    $counter++;
}

$htmlDataParkir .= "</table>
                    <p><center>copyrights &copy; 2023 <i>parkingapps allrights reversed</i> by Rusdi</center>
                    <br><br>
                    Email: rusdioey@gmail.com<br>
                    Github: github.com/gfadsrwt2nd<br>
                    Instagram: @mhdrusdik</p>
                    </body></html>";

// Tentukan header konten sebagai HTML
header("Content-Type: application/html");
header("Content-Disposition: attachment; filename=laporan_data_parkir.html");

// Keluarkan laporan data parkir
echo $htmlDataParkir;

// Tutup koneksi database
mysqli_close($conn);

// Hentikan eksekusi skrip
exit();
?>
