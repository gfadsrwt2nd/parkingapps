<!DOCTYPE html>
<html>
<head>
    <title>Data Parkir</title>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
    <link rel="stylesheet" type="text/css" href="css/dashboard-styles.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

.container {
    width: 80%;
    margin: auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 5px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

h2 {
    text-align: center;
    margin-bottom: 20px;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th, td {
    border: 1px solid #ccc;
    padding: 8px;
    text-align: center;
}

thead {
    background-color: #007bff;
    color: #fff;
}

tbody tr:nth-child(even) {
    background-color: #f2f2f2;
}

tbody tr:hover {
    background-color: #e0e0e0;
}

/* Gaya untuk layar kecil (misalnya perangkat Android) */
@media screen and (max-width: 768px) {
    .container {
        width: 100%;
        padding: 10px;
    }
}

.sidebar {
    width: 250px;
    background-color: #7d7c7c;
    color: #fff;
    height: 100%;
    position: fixed;
    transition: 0.3s;
    overflow-y: auto;
}

.sidebar.active {
    width: 60px;
}

.logo {
    padding: 10px;
    text-align: center;
    font-size: 1.5rem;
    font-weight: bold;
}

.menu {
    list-style: none;
    padding: 0;
    margin: 0;
}

.menu li {
    padding: 15px;
    text-align: left;
}

.menu a {
    text-decoration: none;
    color: #fff;
    transition: 0.3s;
    display: block;
}

.menu a:hover {
    background-color: #919090;
}

/* Tombol untuk menampilkan form tambah data */
#tambahBtn {
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 3px;
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s;
}

#tambahBtn:hover {
    background-color: #0056b3;
}

/* Form tambah data */
#tambahForm {
    display: none;
    margin-top: 20px;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    background-color: #f7f7f7;
}

#tambahForm label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
}

#tambahForm input[type="text"],
#tambahForm select {
    width: 100%;
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 3px;
}

#tambahForm input[type="submit"] {
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 3px;
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s;
}

#tambahForm input[type="submit"]:hover {
    background-color: #0056b3;
}

.action-btn {
    display: inline-block;
    padding: 6px 12px;
    font-size: 14px;
    font-weight: bold;
    text-align: center;
    text-decoration: none;
    border-radius: 3px;
    cursor: pointer;
    transition: background-color 0.3s, color 0.3s;
}

.action-btn.edit {
    background-color: #fa9200;
    color: #fff;
    border: 1px solid #fa9200;
}

.action-btn.edit:hover {
    background-color: #f2b868;
}

.action-btn.delete {
    background-color: #dc3545;
    color: #fff;
    border: 1px solid #dc3545;
}

.action-btn.delete:hover {
    background-color: #c82333;
}

/* Style untuk tombol Cari */
button[type="submit"] {
  background-color: #007bff;
  color: white;
  padding: 8px 12px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

/* Style ketika tombol Cari di-hover */
button[type="submit"]:hover {
  background-color: #0056b3;
}

input[type="text"] {
  padding: 5px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

/* Style ketika input teks di-focus */
input[type="text"]:focus {
  border-color: #007bff;
  outline: none;
}

/* Style untuk input teks saat terjadi kesalahan */
input[type="text"].error {
  border-color: #dc3545;
}

#bottomText {
    align-self: flex-end; /* Menempatkan tulisan di bagian bawah */
    margin-top: auto; /* Menambahkan jarak atas otomatis di atas tulisan */
}
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo">
            <img src="img/logo.png" height="100">
        </div>
        <ul class="menu">
            <li><a href="dashboard.php">Beranda</a></li>
            <li><a href="parking_data.php">Data Parkir</a></li>
            <li><a href="settings_form.php">Tarif Parkir</a></li>
            <li><a href="transaction_history.php">Riwayat Transaksi</a></li>
            <li><a href="report_page.php">Laporan</a></li>

            <!-- Tambahkan menu lain sesuai kebutuhan -->
        </ul>
    </div>

    <div class="container">
        <h2>Data Parkir</h2>
        <!-- Tombol untuk menampilkan form tambah data -->
        <button id="tambahBtn">Tambah Data Parkir</button>
        <form action="search_results.php" method="get">
            <label for="search">Cari Nomor Plat:</label>
            <input type="text" name="search" id="search">
            <button type="submit">Cari</button>
        </form>

        <!-- Form tambah data parkir -->
        <div id="tambahForm" style="display: none;">
            <form action="process_tambah_parkir.php" method="post">
                <label for="vehicle_plate">Nomor Plat:</label>
                <input type="text" name="vehicle_plate" required>
                <label for="vehicle_type">Jenis Kendaraan:</label>
                <select name="vehicle_type" required>
                    <option value="mobil">Mobil</option>
                    <option value="motor">Motor</option>
                </select>
                <label for="vehicle_brand">Merk Kendaraan:</label>
                <input type="text" name="vehicle_brand" required>
                <label for="entry_time">Waktu Masuk:</label>
                <input type="datetime-local" name="entry_time" required><br><br>
                <input type="submit" name="submit" value="Tambah Data">
            </form>
        </div>

        <table>
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Nomor Plat</th>
                    <th>Jenis Kendaraan</th>
                    <th>Merk</th>
                    <th>Waktu Masuk</th>
                    <th>Waktu Keluar</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $conn = mysqli_connect("localhost", "root", "", "park");

                if (!$conn) {
                    die("Koneksi ke database gagal: " . mysqli_connect_error());
                }

                $query = "SELECT * FROM parkingrecords";
                $result = mysqli_query($conn, $query);

                $counter = 1;
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . $counter . "</td>";
                    echo "<td>" . $row["vehicle_plate"] . "</td>";
                    echo "<td>" . $row["vehicle_type"] . "</td>";
                    echo "<td>" . $row["vehicle_brand"] . "</td>";
                    echo "<td>" . $row["entry_time"] . "</td>";
                    echo "<td>" . $row["exit_time"] . "</td>";
                    echo "<td>" . $row["status"] . "</td>";
                    echo "<td>";
                    echo '<a class="action-btn edit" href="edit_parking_record.php?id=' . $row["record_id"] . '">Edit </a>';
                    echo "<font color='black'> | </font>";
                    echo '<a class="action-btn delete" href="delete_parking_record.php?id=' . $row["record_id"] . '">Hapus</a>';
                    echo "</td>";
                    echo "</tr>";
                    $counter++;
                }

                mysqli_close($conn);
                ?>
            </tbody>
        </table>
    </div>

    <!-- Tambahkan JavaScript Anda di sini -->
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const tambahBtn = document.getElementById("tambahBtn");
            const tambahForm = document.getElementById("tambahForm");

            tambahBtn.addEventListener("click", function () {
                if (tambahForm.style.display === "none") {
                    tambahForm.style.display = "block";
                } else {
                    tambahForm.style.display = "none";
                }
            });
        });
    </script>
</body>
</html>
