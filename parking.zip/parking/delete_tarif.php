<?php
// Connect to your database and perform the necessary deletion process
$conn = mysqli_connect("localhost", "root", "", "park");

if (!$conn) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}

if (isset($_POST["rate_id"])) {
    $rate_id = $_POST["rate_id"];

    // Perform deletion query here
    $query = "DELETE FROM parkingrates WHERE rate_id = $rate_id";
    $result = mysqli_query($conn, $query);

    if ($result) {
        echo "Tarif berhasil dihapus";
    } else {
        echo "Gagal menghapus tarif: " . mysqli_error($conn);
    }
} else {
    echo "ID tarif tidak ditemukan";
}

mysqli_close($conn);
?>
