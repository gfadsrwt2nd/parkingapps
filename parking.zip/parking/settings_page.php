<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "park";

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$sql = "SELECT * FROM parkingrates";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Pengaturan Biaya Parkir</title>
</head>
<style type="text/css">
  body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

/* Style untuk container halaman */
.container {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 5px;
  background-color: #f9f9f9;
}

/* Style untuk judul halaman */
h2 {
  font-size: 24px;
  margin-bottom: 15px;
}

/* Style untuk data biaya parkir */
p {
  font-size: 16px;
  margin-bottom: 10px;
}

/* Style untuk tombol kembali */
.back-button {
  display: inline-block;
  padding: 8px 15px;
  background-color: #3498db;
  color: #fff;
  text-decoration: none;
  border-radius: 4px;
  font-size: 14px;
  transition: background-color 0.3s ease;
}

.back-button:hover {
  background-color: #2980b9;
}

/* Style untuk garis pemisah antara data */
hr {
  margin: 15px 0;
  border: none;
  border-top: 1px solid #ccc;
}

.sidebar {
    width: 250px;
    background-color: #7d7c7c;
    color: #fff;
    height: 100%;
    position: fixed;
    transition: 0.3s;
    overflow-y: auto;
}

.sidebar.active {
    width: 60px;
}

.logo {
    padding: 10px;
    text-align: center;
    font-size: 1.5rem;
    font-weight: bold;
}

.menu {
    list-style: none;
    padding: 0;
    margin: 0;
}

.menu li {
    padding: 15px;
    text-align: left;
}

.menu a {
    text-decoration: none;
    color: #fff;
    transition: 0.3s;
    display: block;
}

.menu a:hover {
    background-color: #919090;
}

.container2 {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 5px;
  background-color: #f9f9f9;
}

.delete-button {
  background-color: #dc3545;
  color: white;
  padding: 10px 21px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s;
}

.delete-button:hover {
  background-color: #c82333;
}

a {
  text-decoration: none;
}
</style>
<body>
    <div class="sidebar">
        <div class="logo">
            <img src="img/logo.png" height="100">
        </div>
        <ul class="menu">
            <li><a href="dashboard.php">Beranda</a></li>
            <li><a href="parking_data.php">Data Parkir</a></li>
            <li><a href="settings_form.php">Tarif Parkir</a></li>
            <li><a href="transaction_history.php">Riwayat Transaksi</a></li>
            <li><a href="report_page.php">Laporan</a></li>
            <!-- Tambahkan menu lain sesuai kebutuhan -->
        </ul>
    </div>

    <div class="container2">
    <h2>Pengaturan Biaya Parkir</h2>
    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<p>Vehicle Type: " . $row["vehicle_type"] . "</p>";
            echo "<p>Hourly Rate: Rp " . number_format($row["hourly_rate"], 2) . "</p>";
            echo "<p>Daily Rate: Rp " . number_format($row["daily_rate"], 2) . "</p>";
            // ...
            echo "<hr>";
            echo "<a class=\"back-button\" href=\"javascript:history.go(-1)\">Kembali</a>";
            echo "<br><br>";
            // Use $row["rate_id"] for the rate_id value
            echo '<form action="delete_tarif.php" method="post" onsubmit="return confirm(\'Apakah Anda yakin ingin menghapus tarif ini?\');">
                  <input type="hidden" name="rate_id" value="' . $row["rate_id"] . '">
                  <input type="submit" name="delete" value="Hapus" class="delete-button">
                </form>';
        }
    } else {
        echo "Tidak ada data biaya parkir.";
    }
    ?>
  </div>
</body>
</html>

<?php
$conn->close();
?>
