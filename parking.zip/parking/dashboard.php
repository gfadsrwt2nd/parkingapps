<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" type="text/css" href="css/dashboard-styles.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<style type="text/css">
footer {
    background-color: #333; /* Warna latar belakang footer */
    color: #fff; /* Warna teks footer */
    padding: 20px; /* Ruang dalam footer dari teks ke batas footer */
    text-align: center; /* Pusatkan teks di dalam footer */
}

/* CSS untuk tautan dalam footer (jika diperlukan) */
footer a {
    color: #fff; /* Warna tautan di dalam footer */
    text-decoration: none; /* Hilangkan garis bawah dari tautan */
}

/* CSS untuk tautan dalam footer saat dihover (jika diperlukan) */
footer a:hover {
    text-decoration: underline; /* Tampilkan garis bawah pada hover tautan */
}
</style>
<body>
    <div class="sidebar">
        <div class="logo">
            <img src="img/logo.png" height="100">
        </div>
        <ul class="menu">
            <li><a href="dashboard.php">Beranda</a></li>
            <li><a href="parking_data.php">Data Parkir</a></li>
            <li><a href="settings_form.php">Tarif Parkir</a></li>
            <li><a href="transaction_history.php">Riwayat Transaksi</a></li>
            <li><a href="report_page.php">Laporan</a></li>
            <!-- Tambahkan menu lain sesuai kebutuhan -->
        </ul>
    </div>

    <div class="container">
        <h2>Dashboard</h2>
        <div class="chart-container">
            <canvas id="parkingChart"></canvas>
        </div>
        <div class="statistics">
            <div class="stat-box">
                <h3>Penghasilan</h3>
                <p>Rp 15,000,000</p>
            </div>
            <div class="stat-box">
                <h3>Kapasitas Parkir Tersedia</h3>
                <p>30</p>
            </div>
            <!-- Tambahkan statistik lain sesuai kebutuhan -->
        </div>
    </div>



    <script src="js/script.js"></script>
    <script src="js/staticbar.script.js"></script>
</body>
</html>
