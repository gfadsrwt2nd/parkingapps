<!DOCTYPE html>
<html>
<head>
    <title>Riwayat Transaksi</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<style type="text/css">
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

.container {
    width: 80%;
    margin: auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 5px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

h2 {
    text-align: center;
    margin-bottom: 20px;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th, td {
    border: 1px solid #ccc;
    padding: 8px;
    text-align: center;
}

thead {
    background-color: #007bff;
    color: #fff;
}

tbody tr:nth-child(even) {
    background-color: #f2f2f2;
}

tbody tr:hover {
    background-color: #e0e0e0;
}

.sidebar {
    width: 250px;
    background-color: #7d7c7c;
    color: #fff;
    height: 100%;
    position: fixed;
    transition: 0.3s;
    overflow-y: auto;
}

.sidebar.active {
    width: 60px;
}

.logo {
    padding: 10px;
    text-align: center;
    font-size: 1.5rem;
    font-weight: bold;
}

.menu {
    list-style: none;
    padding: 0;
    margin: 0;
}

.menu li {
    padding: 15px;
    text-align: left;
}

.menu a {
    text-decoration: none;
    color: #fff;
    transition: 0.3s;
    display: block;
}

.menu a:hover {
    background-color: #919090;
}
#tambahBtn {
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 3px;
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s;
}

#tambahBtn:hover {
    background-color: #0056b3;
}

/* Form tambah data */
#tambahForm {
    display: none;
    margin-top: 20px;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    background-color: #f7f7f7;
}

#tambahForm label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
}

#tambahForm input[type="text"],
#tambahForm select {
    width: 100%;
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 3px;
}

#tambahForm input[type="submit"] {
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 3px;
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s;
}

#tambahForm input[type="submit"]:hover {
    background-color: #0056b3;
}

.action-btn {
    display: inline-block;
    padding: 6px 12px;
    font-size: 14px;
    font-weight: bold;
    text-align: center;
    text-decoration: none;
    border-radius: 3px;
    cursor: pointer;
    transition: background-color 0.3s, color 0.3s;
}

.action-btn.back {
    background-color: #027efa;
    color: #fff;
    border: 1px solid #027efa;
}

.action-btn.back:hover {
    background-color: #034d96;
}

.action-btn.add {
    background-color: #06ad02;
    color: #fff;
    border: 1px solid #33ba2f;
}

.action-btn.add:hover {
    background-color: #188215;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

table, th, td {
    border: 1px solid #ddd;
}

th {
    background-color: #007bff;
    color: #fff;
    text-align: left;
    padding: 10px;
}

tr:nth-child(even) {
    background-color: #f2f2f2;
}

tr:hover {
    background-color: #ddd;
}

</style>
<body>
    <div class="sidebar">
        <div class="logo">
            <img src="img/logo.png" height="100">
        </div>
        <ul class="menu">
            <li><a href="dashboard.php">Beranda</a></li>
            <li><a href="parking_data.php">Data Parkir</a></li>
            <li><a href="settings_form.php">Tarif Parkir</a></li>
            <li><a href="transaction_history.php">Riwayat Transaksi</a></li>
            <li><a href="report_page.php">Laporan</a></li>
            <!-- Tambahkan menu lain sesuai kebutuhan -->
        </ul>
    </div>
    
    <div class="container">
        <h2>Riwayat Transaksi</h2>
            <a class="action-btn back" href="dashboard.php">Kembali </a>
            <a class="action-btn add" href="add_transaction.php">Tambah Data Transaksi</a>
        <br><br>
        <?php
        // Menghubungkan ke database
        $conn = mysqli_connect("localhost", "root", "", "park");

        if (!$conn) {
            die("Koneksi ke database gagal: " . mysqli_connect_error());
        }

        // Mengambil data dari tabel paymenttransactions dan parkingrecords
        $query = "SELECT pt.*, pr.entry_time, pr.exit_time, pr.vehicle_plate
                  FROM paymenttransactions pt
                  INNER JOIN parkingrecords pr ON pt.record_id = pr.record_id";
        $result = mysqli_query($conn, $query);

        if ($result && mysqli_num_rows($result) > 0) {
            echo "<table>";
            echo "<tr>
                    <th>No.</th>
                    <th>Record ID</th>
                    <th>Nomor Plat</th>
                    <th>Waktu Masuk</th>
                    <th>Waktu Keluar</th>
                    <th>Durasi Parkir</th>
                    <th>Biaya</th>
                  </tr>";

            $counter = 1;
            while ($row = mysqli_fetch_assoc($result)) {
                $entryTime = strtotime($row["entry_time"]);
                $exitTime = strtotime($row["exit_time"]);
                $parkingDuration = round(($exitTime - $entryTime) / 60); // Menghitung durasi dalam menit

                echo "<tr>";
                echo "<td>" . $counter . "</td>";
                echo "<td>" . $row["record_id"] . "</td>";
                echo "<td>" . $row["vehicle_plate"] . "</td>";
                echo "<td>" . $row["entry_time"] . "</td>";
                echo "<td>" . $row["exit_time"] . "</td>";
                echo "<td>" . $parkingDuration . " menit</td>";
                echo "<td>Rp " . number_format($row["payment_amount"], 2) . "</td>";
                echo "</tr>";
                $counter++;
            }

            echo "</table>";
        } else {
            echo "<p>Tidak ada data transaksi.</p>";
        }

        mysqli_close($conn);
        ?>
    </div>
</body>
</html>
