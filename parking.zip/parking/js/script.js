const sidebar = document.querySelector('.sidebar');
const content = document.querySelector('.content');

document.querySelector('.logo').addEventListener('click', () => {
    sidebar.classList.toggle('active');
    content.classList.toggle('active');
});
