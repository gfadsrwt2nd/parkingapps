<?php
if (isset($_POST["submit"])) {
    // Get data from the form
    $setting_id = $_POST["setting_id"];
    $setting_name = $_POST["setting_name"];
    $setting_value = $_POST["setting_value"];

    // Check if any required fields are empty
    if (empty($setting_name) || empty($setting_value)) {
        echo "Error: All fields are required.";
    } else {
        // Connect to the database
        $conn = mysqli_connect("localhost", "root", "", "park");

        if (!$conn) {
            die("Connection to the database failed: " . mysqli_connect_error());
        }

        // Perform the update query
        $query = "UPDATE settings SET setting_name = '$setting_name', setting_value = '$setting_value' WHERE setting_id = $setting_id";
        $result = mysqli_query($conn, $query);

        if ($result) {
            mysqli_close($conn);
            header("Location: settings_page.php");
            exit;
        } else {
            echo "Error: " . mysqli_error($conn);
        }

        mysqli_close($conn);
    }
} else {
    echo "Form was not submitted.";
}
?>
