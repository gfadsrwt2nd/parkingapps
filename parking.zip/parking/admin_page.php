<!DOCTYPE html>
<html>
<head>
    <title>Halaman Admin</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<style type="text/css">
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

.container {
    width: 80%;
    margin: auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 5px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

h2 {
    text-align: center;
    margin-bottom: 20px;
}

nav ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

nav li {
    margin-bottom: 10px;
}

nav a {
    text-decoration: none;
    color: #007bff;
    font-weight: bold;
    transition: color 0.3s, transform 0.3s;
}

nav a:hover {
    color: #0056b3;
    transform: scale(1.1);
}

</style>
<body>
    <div class="container">
        <h2>Halaman Admin</h2>
        <nav>
            <ul>
                <li><a href="manage_users.php">Kelola Pengguna</a></li>
                <li><a href="manage_transactions.php">Kelola Transaksi</a></li>
                <li><a href="settings.php">Pengaturan</a></li>
                <!-- Tambahkan tautan lain sesuai kebutuhan -->
            </ul>
        </nav>
    </div>
</body>
</html>
