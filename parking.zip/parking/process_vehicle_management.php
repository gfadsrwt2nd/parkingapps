<?php
$host = 'localhost'; // Ganti dengan host database Anda
$username = 'root'; // Ganti dengan username database Anda
$password = ''; // Ganti dengan password database Anda
$database = 'park'; // Ganti dengan nama database Anda

$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $vehicleType = $_POST["vehicle_type"];
    $vehiclePlate = $_POST["vehicle_plate"];
    $vehicleBrand = $_POST["vehicle_brand"]; // Menambahkan data merk kendaraan

    // Lakukan validasi data jika diperlukan

    $insertQuery = "INSERT INTO vehicle (vehicle_type, vehicle_plate, vehicle_brand) 
                    VALUES ('$vehicleType', '$vehiclePlate', '$vehicleBrand')";

    if (mysqli_query($conn, $insertQuery)) {
        echo "Data kendaraan berhasil ditambahkan.";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}


mysqli_close($conn);
?>
