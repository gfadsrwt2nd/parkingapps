<?php
if (isset($_POST["submit"])) {
    $record_id = $_POST["record_id"];
    $payment_amount = $_POST["payment_amount"];
    $payment_time = $_POST["payment_time"];
    $payment_method = $_POST["payment_method"];
    $receipt_number = $_POST["receipt_number"];

    // Menghubungkan ke database
    $conn = mysqli_connect("localhost", "root", "", "park");

    if (!$conn) {
        die("Koneksi ke database gagal: " . mysqli_connect_error());
    }

    // Periksa apakah record_id ada di tabel parkingrecords
    $check_query = "SELECT * FROM parkingrecords WHERE record_id = $record_id";
    $check_result = mysqli_query($conn, $check_query);

    if ($check_result && mysqli_num_rows($check_result) > 0) {
        // Data parkir ditemukan, maka tambahkan data transaksi
        $insert_query = "INSERT INTO paymenttransactions (record_id, payment_amount, payment_time, payment_method, receipt_number) VALUES ($record_id, $payment_amount, '$payment_time', '$payment_method', '$receipt_number')";
        $insert_result = mysqli_query($conn, $insert_query);

        if ($insert_result) {
            mysqli_close($conn);
            header("Location: transaction_history.php"); // Redirect kembali ke halaman riwayat transaksi
            exit;
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        echo "Record ID tidak ditemukan.";
    }

    mysqli_close($conn);
}
?>
