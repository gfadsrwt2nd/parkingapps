<!DOCTYPE html>
<html>
<head>
    <title>Aplikasi Manajemen Parkir</title>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <div class="container">
        <h1>Selamat Datang di Aplikasi Manajemen Parkir</h1>
        <p>Ini adalah aplikasi yang membantu Anda mengelola parkir dengan efisien.</p>
        <p>Silakan gunakan navigasi untuk mengakses fitur-fitur kami.</p>
        <nav>
            <ul>
                <li><a href="user_registration.php">Daftar</a></li>
                <li><a href="user_login.php">Masuk</a></li>
                <li><a href="vehicle_entry.php">Catat Kendaraan Masuk</a></li>
                <li><a href="vehicle_exit.php">Catat Kendaraan Keluar</a></li>
                <li><a href="parking_data.php">Tampilkan Data Parkir</a></li>
                <li><a href="transaction_history.php">History Transaksi</a></li>
                <!-- Tambahkan tautan lain sesuai kebutuhan -->
            </ul>
        </nav>
    </div>
</body>
</html>
